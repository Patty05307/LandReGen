# 🌱 Land ReGen – AI-Powered Soil Degradation Detection

## Overview
Land ReGen is a solo hackathon prototype for SDG 15: Life on Land. It uses NASA MODIS remote sensing (NDVI) and a simple AI endpoint to assess soil degradation risk and provide recommendations.

## Features
- Backend REST API for soil health, land use, and monitoring
- GIS/remote sensing API integration
- AI model for early detection of soil degradation
- Web dashboard for data visualization and land management
- Supabase authentication and database (optional)
- Reforestation/restoration planning and analytics

## Tech Stack
- Frontend: React + Recharts
- Backend: FastAPI + Uvicorn
- Python libs: scikit-learn, tensorflow (for future model integration)

## Getting Started

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm start
```

Visit http://localhost:3000 after starting both backend and frontend.

## Developer
**Project Author:** Patience Ibitokun  
**Hackathon:** Land ReGen Hackathon 2025  
**Focus:** AI-Powered Soil Degradation Monitoring for SDG 15 – Life on Land
